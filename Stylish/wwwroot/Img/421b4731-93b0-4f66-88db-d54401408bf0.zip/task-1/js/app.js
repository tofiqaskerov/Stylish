
var barIcon=document.getElementById("bar-ico")
var ResponsiveMenu=document.querySelector("#header .responsive-menu")

barIcon.onclick=function(){
   ResponsiveMenu.classList.toggle("active-menu")
}



 
      



  
